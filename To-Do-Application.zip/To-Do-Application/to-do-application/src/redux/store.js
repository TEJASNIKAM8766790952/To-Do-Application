import { createStore } from 'redux';
import { Provider } from 'react-redux';
import todoReducer from './reducers';

const store = createStore(todoReducer);

export const TodoApp = ({ children }) => (
  <Provider store={store}>
    {children}
  </Provider>
);
