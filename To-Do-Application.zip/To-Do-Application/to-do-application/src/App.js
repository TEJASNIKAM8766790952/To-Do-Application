import React from 'react';
import TodoInput from './components/TodoInput';
import TodoList from './components/TodoList';
import TodoFilter from './components/TodoFilter';

const App = () => (
  <div>
    <h1>To-Do List</h1>
    <TodoInput />
    <TodoFilter />
    <TodoList />
  </div>
);

export default App;
