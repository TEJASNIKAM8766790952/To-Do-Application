import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import { TodoApp } from './redux/store';

ReactDOM.render(
  <React.StrictMode>
    <TodoApp>
      <App />
    </TodoApp>
  </React.StrictMode>,
  document.getElementById('root')
);
